const User = require("../models/userModel");
const bcrypt = require("bcryptjs");

const createUser = async (userData) => {
    const hashedPassword = await bcrypt.hash(userData.password, 12);

    return await User.create({
        ...userData,
        password: hashedPassword
    });
};

const findByEmail = async (email) => {
    return await User.findOne({
        email: email.toLowerCase().trim()
    }).select("+password");
};

const getAllStudents = async () => {
    return await User.find({ role: "Student" });
};

const getAllTeachers = async () => {
    return await User.find({ role: "Teacher" });
};

const getStudentById = async (id) => {
    return await User.findOne({
        _id: id,
        role: "Student"
    });
};

const getTeacherById = async (id) => {
    return await User.findOne({
        _id: id,
        role: "Teacher"
    });
};

const updateProfile = async (userId, updateData) => {
    return await User.findByIdAndUpdate(
        userId,
        { $set: updateData },
        {
            new: true,
            runValidators: true
        }
    );
};

const updateStudent = async (studentId, updateData) => {
    return await User.findOneAndUpdate(
        {
            _id: studentId,
            role: "Student"
        },
        { $set: updateData },
        {
            new: true,
            runValidators: true
        }
    );
};

module.exports = {
    createUser,
    findByEmail,
    getAllStudents,
    getAllTeachers,
    getStudentById,
    getTeacherById,
    updateProfile,
    updateStudent
};