const express = require("express");
const router = express.Router();
const userController = require("../controllers/userController");
const authMiddleware = require("../middlewares/authMiddleware");
const authorizeRoles = require("../middlewares/permissionMiddleware");
// Public APIs
router.post("/signup", userController.signup);
router.post("/login", userController.login);

// Student and Teacher APIs
router.get("/students",authMiddleware,
    authorizeRoles("Student", "Teacher"),
    userController.getAllStudents);

router.get(
    "/students/:id",
    authMiddleware,
    authorizeRoles("Student", "Teacher"),
    userController.getStudentById
);

router.patch(
    "/profile",
    authMiddleware,
    authorizeRoles("Student", "Teacher"),
    userController.updateProfile
);

// Teacher-only APIs
router.get(
    "/teachers",
    authMiddleware,
    authorizeRoles("Teacher"),
    userController.getAllTeachers
);

router.get(
    "/teachers/:id",
    authMiddleware,
    authorizeRoles("Teacher"),
    userController.getTeacherById
);

router.patch(
    "/students/:id",
    authMiddleware,
    authorizeRoles("Teacher"),
    userController.updateStudent
);

module.exports = router;    