const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const mongoose = require("mongoose");
const userService = require("../services/userService");

const allowedProfileFields = [
    "name",
    "department",
    "phone",
    "rollNumber",
    "employeeId",
    "year"
];

const filterProfileData = (body) => {
    const data = {};

    for (const field of allowedProfileFields) {
        if (body[field] !== undefined) {
            data[field] = body[field];
        }
    }

    return data;
};

const isValidId = (id) => mongoose.Types.ObjectId.isValid(id);

const signup = async (req, res) => {
    try {
        const { name, email, password, role } = req.body;

        if (!name || !email || !password || !role) {
            return res.status(400).json({
                success: false,
                message: "Name, email, password and role are required."
            });
        }

        if (!["Student", "Teacher"].includes(role)) {
            return res.status(400).json({
                success: false,
                message: "Role must be Student or Teacher."
            });
        }

        if (typeof password !== "string" || password.length < 8) {
            return res.status(400).json({
                success: false,
                message: "Password must contain at least 8 characters."
            });
        }

        const normalizedEmail = email.trim().toLowerCase();

        const existingUser = await userService.findByEmail(normalizedEmail);

        if (existingUser) {
            return res.status(409).json({
                success: false,
                message: "Email already registered."
            });
        }

        const profileData = filterProfileData(req.body);

        const user = await userService.createUser({
            ...profileData,
            name: name.trim(),
            email: normalizedEmail,
            password,
            role
        });

        return res.status(201).json({
            success: true,
            message: "Signup successful.",
            data: user
        });
    } catch (error) {
        if (error.code === 11000) {
            return res.status(409).json({
                success: false,
                message: "Email already registered."
            });
        }

        return res.status(500).json({
            success: false,
            message: "Signup failed.",
            error: error.message
        });
    }
};

const login = async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                success: false,
                message: "Email and password are required."
            });
        }

        const user = await userService.findByEmail(email);

        if (!user) {
            return res.status(401).json({
                success: false,
                message: "Invalid email or password."
            });
        }

        const isMatch = await bcrypt.compare(password, user.password);

        if (!isMatch) {
            return res.status(401).json({
                success: false,
                message: "Invalid email or password."
            });
        }

        if (!process.env.JWT_SECRET) {
            return res.status(500).json({
                success: false,
                message: "JWT_SECRET is missing from environment variables."
            });
        }

        const token = jwt.sign(
            {
                id: user._id.toString()
            },
            process.env.JWT_SECRET,
            {
                expiresIn: process.env.JWT_EXPIRES_IN || "1d"
            }
        );

        return res.status(200).json({
            success: true,
            message: "Login successful.",
            token,
            data: {
                id: user._id,
                name: user.name,
                email: user.email,
                role: user.role
            }
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: "Login failed.",
            error: error.message
        });
    }
};

const getAllStudents = async (req, res) => {
    try {
        const students = await userService.getAllStudents();

        return res.status(200).json({
            success: true,
            count: students.length,
            data: students
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: "Failed to retrieve students.",
            error: error.message
        });
    }
};

const getAllTeachers = async (req, res) => {
    try {
        const teachers = await userService.getAllTeachers();

        return res.status(200).json({
            success: true,
            count: teachers.length,
            data: teachers
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: "Failed to retrieve teachers.",
            error: error.message
        });
    }
};

const getStudentById = async (req, res) => {
    try {
        if (!isValidId(req.params.id)) {
            return res.status(400).json({
                success: false,
                message: "Invalid student ID."
            });
        }

        const student = await userService.getStudentById(req.params.id);

        if (!student) {
            return res.status(404).json({
                success: false,
                message: "Student not found."
            });
        }

        return res.status(200).json({
            success: true,
            data: student
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: "Failed to retrieve student.",
            error: error.message
        });
    }
};

const getTeacherById = async (req, res) => {
    try {
        if (!isValidId(req.params.id)) {
            return res.status(400).json({
                success: false,
                message: "Invalid teacher ID."
            });
        }

        const teacher = await userService.getTeacherById(req.params.id);

        if (!teacher) {
            return res.status(404).json({
                success: false,
                message: "Teacher not found."
            });
        }

        return res.status(200).json({
            success: true,
            data: teacher
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: "Failed to retrieve teacher.",
            error: error.message
        });
    }
};

const updateProfile = async (req, res) => {
    try {
        const updateData = filterProfileData(req.body);

        if (Object.keys(updateData).length === 0) {
            return res.status(400).json({
                success: false,
                message: "Provide at least one valid profile field to update."
            });
        }

        const updatedUser = await userService.updateProfile(
            req.user._id,
            updateData
        );

        return res.status(200).json({
            success: true,
            message: "Profile updated successfully.",
            data: updatedUser
        });
    } catch (error) {
        return res.status(400).json({
            success: false,
            message: "Failed to update profile.",
            error: error.message
        });
    }
};

const updateStudent = async (req, res) => {
    try {
        if (!isValidId(req.params.id)) {
            return res.status(400).json({
                success: false,
                message: "Invalid student ID."
            });
        }

        const updateData = filterProfileData(req.body);

        if (Object.keys(updateData).length === 0) {
            return res.status(400).json({
                success: false,
                message: "Provide at least one valid student field to update."
            });
        }

        const updatedStudent = await userService.updateStudent(
            req.params.id,
            updateData
        );

        if (!updatedStudent) {
            return res.status(404).json({
                success: false,
                message: "Student not found."
            });
        }

        return res.status(200).json({
            success: true,
            message: "Student updated successfully.",
            data: updatedStudent
        });
    } catch (error) {
        return res.status(400).json({
            success: false,
            message: "Failed to update student.",
            error: error.message
        });
    }
};

module.exports = {
    signup,
    login,
    getAllStudents,
    getAllTeachers,
    getStudentById,
    getTeacherById,
    updateProfile,
    updateStudent
};