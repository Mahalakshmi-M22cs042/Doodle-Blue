const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: [true, "Name is required"],
            trim: true
        },

        email: {
            type: String,
            required: [true, "Email is required"],
            unique: true,
            lowercase: true,
            trim: true
        },

        password: {
            type: String,
            required: [true, "Password is required"],
            select: false
        },

        role: {
            type: String,
            enum: ["Student", "Teacher"],
            required: true
        },

        department: {
            type: String,
            trim: true,
            default: ""
        },

        phone: {
            type: String,
            trim: true,
            default: ""
        },

        rollNumber: {
            type: String,
            trim: true,
            default: ""
        },

        employeeId: {
            type: String,
            trim: true,
            default: ""
        },

        year: {
            type: Number,
            min: 1,
            max: 6,
            default: null
        }
    },
    {
        timestamps: true,
        versionKey: false
    }
);

module.exports = mongoose.model("User", userSchema);