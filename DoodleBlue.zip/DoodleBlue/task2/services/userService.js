
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const User = require("../models/loginModel");
const jwt = require("jsonwebtoken");

class UserService {
    async userSignup({ name, email, password }) {
        const salt=10;
        const hashedPassword = await bcrypt.hash(password, salt);
        const savedUser = await User.create({ name, email, password: hashedPassword });
        return savedUser;
    }
    // Get all users
    async getAllUsers() {
        //return await User.find();
        return await User.find({isActive: true});
        //.select("-password");
    }

    // Get user by ID
    async getUserById(id) {
        if (!mongoose.isValidObjectId(id)) {
            return null;
        }

        return await User.findById(id);
    }

    // Create a new user
    async createUser({ name, email }) {
        return await User.create({ name, email });
    }

    // PUT - Update the complete user details
    async updateUser(id, { name, email }) {
        if (!mongoose.isValidObjectId(id)) {
            return null;
        }

        return await User.findByIdAndUpdate(
            id,
            { name, email },
            {
                new: true,
                runValidators: true
            }
        );
    }

    // PATCH - Update only the provided fields
    async patchUser(id, updates) {
        if (!mongoose.isValidObjectId(id)) {
            return null;
        }

        const allowedFields = ["name", "email"];
        const filteredUpdates = {};

        for (const field of allowedFields) {
            if (updates[field] !== undefined) {
                filteredUpdates[field] = updates[field];
            }
        }

        if (Object.keys(filteredUpdates).length === 0) {
            throw new Error("Provide name or email to update");
        }

        return await User.findByIdAndUpdate(
            id,
            { $set: filteredUpdates },
            {
                new: true,
                runValidators: true
            }
        );
    }
    // DELETE - Delete user by ID
 // Normal delete / hard delete
async deleteUser(id) {
    if (!mongoose.isValidObjectId(id)) {
        return null;
    }

    return await User.findByIdAndDelete(id);
}
// Explicit hard delete
async hardDeleteUser(id) {
    if (!mongoose.isValidObjectId(id)) {
        return null;
    }
    return await User.findByIdAndDelete(id);
}

async loginUser({ email, password }) {
    const user = await User.findOne({
        email: email.trim().toLowerCase(),
        isActive: true
    }).select("+password");

    if (!user) {
        return null;
    }

    const isPasswordValid = await bcrypt.compare(
        password,
        user.password
    );

    if (!isPasswordValid) {
        return null;
    }

    return {
        id: user._id.toString(),
        name: user.name,
        email: user.email
    };
}

// Soft delete
async softDeleteUser(id) {
    if (!mongoose.isValidObjectId(id)) {
        return null;
    }

    return await User.findOneAndUpdate(
        {
            _id: id,
            isActive: true
        },
        {
            $set: { isActive: false }
        },
        {
            new: true,
            runValidators: true
        }
    );
}
}

module.exports = UserService;