const mongoose = require("mongoose");

const loginSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      trim: true
    },
    email: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true
    },
    password: {
      type: String,
      required: true,
      select: false
    },
    isActive: {
      type: Boolean,
      default: true
    }
  },
  { timestamps: true, collection: "login" }
);

module.exports = mongoose.model("Login", loginSchema);