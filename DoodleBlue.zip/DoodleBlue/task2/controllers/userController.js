
const Login = require("../models/loginModel");
const bcrypt = require("bcryptjs");
const userService = require("../services/userService");
const jwt = require("jsonwebtoken");
// CREATE USER
exports.createUser = async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (
      typeof name !== "string" || !name.trim() ||
      typeof email !== "string" || !email.trim() ||
      typeof password !== "string" || !password
    ) {
      return res.status(400).json({
        message: "Name, email, and password are required"
      });
    }
    const normalizedEmail = email.trim().toLowerCase();
    const existingUser = await Login.findOne({
      email: normalizedEmail
    });
    if (existingUser) {
      return res.status(409).json({
        message: "Email already exists"
      });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await Login.create({
      name: name.trim(),
      email: normalizedEmail,
      password: hashedPassword
    });
    return res.status(201).json({
      message: "User created successfully",
      data: {
        id: user._id,
        name: user.name,
        email: user.email
      }
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({
        message: "Email already exists"
      });
    }
    return res.status(500).json({
      message: "Failed to create user"
    });
  }
};
// READ ALL USERS
exports.getAllUsers = async (req, res) => {
  try {
    const users = await Login.find().select("-password");
    return res.status(200).json({
      message: "Users retrieved successfully",
      count: users.length,
      data: users
    });
  } catch (error) {
    return res.status(500).json({
      message: "Failed to retrieve users"
    });
  }
};
// READ ONE USER
exports.getUserById = async (req, res) => {
  try {
    const user = await Login.findById(req.params.id)
      .select("-password");
    if (!user) {
      return res.status(404).json({
        message: "User not found"
      });
    }
    return res.status(200).json({
      data: user
    });
  } catch (error) {
    if (error.name === "CastError") {
      return res.status(400).json({
        message: "Invalid user ID"
      });
    }
    return res.status(500).json({
      message: "Failed to retrieve user"
    });
  }
};
// UPDATE USER
exports.updateUser = async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const updates = {};
    if (
      name !== undefined &&
      (typeof name !== "string" || !name.trim())
    ) {
      return res.status(400).json({
        message: "Name must be a non-empty string"
      });
    }
    if (
      email !== undefined &&
      (typeof email !== "string" || !email.trim())
    ) {
      return res.status(400).json({
        message: "Email must be a non-empty string"
      });
    }
    if (
      password !== undefined &&
      (typeof password !== "string" || !password)
    ) {
      return res.status(400).json({
        message: "Password must be a non-empty string"
      });
    }
    if (name !== undefined) updates.name = name.trim();
    if (email !== undefined) {
      updates.email = email.trim().toLowerCase();
    }
    if (password !== undefined) {
      updates.password = await bcrypt.hash(password, 10);
    }
    if (Object.keys(updates).length === 0) {
      return res.status(400).json({
        message: "Provide at least one field to update"
      });
    }
    const user = await Login.findByIdAndUpdate(
      req.params.id,
      { $set: updates },
      { new: true, runValidators: true }
    ).select("-password");
    if (!user) {
      return res.status(404).json({
        message: "User not found"
      });
    }
    return res.status(200).json({
      message: "User updated successfully",
      data: user
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({
        message: "Email already exists"
      });
    }
    if (error.name === "CastError") {
      return res.status(400).json({
        message: "Invalid user ID"
      });
    }
    return res.status(500).json({
      message: "Failed to update user"
    });
  }
};

//LOGIN USER
exports.loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        message: "Email and password are required"
      });
    }

    if (!process.env.JWT_SECRET) {
      return res.status(500).json({
        message: "JWT_SECRET is not configured"
      });
    }

    const user = await Login.findOne({
      email: email.trim().toLowerCase(),
      isActive: true
    }).select("+password");

    if (!user) {
      return res.status(401).json({
        message: "Invalid email or password"
      });
    }

    const isPasswordValid = await bcrypt.compare(
      password,
      user.password
    );

    if (!isPasswordValid) {
      return res.status(401).json({
        message: "Invalid email or password"
      });
    }

    const token = jwt.sign(
      {
        id: user._id.toString(),
        name: user.name,
        email: user.email
      },
      process.env.JWT_SECRET,
      {
        expiresIn: process.env.JWT_EXPIRES_IN || "1h"
      }
    );

    return res.status(200).json({
      message: "Login successful",
      token: token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email
      }
    });

  } catch (error) {
    return res.status(500).json({
      message: "Login failed"
    });
  }
};
// DELETE USER
exports.deleteUser = async (req, res) => {
  try {
    const user = await Login.findByIdAndDelete(req.params.id);
    if (!user) {
      return res.status(404).json({
        message: "User not found"
      });
    }
    return res.status(200).json({
      message: "User deleted successfully"
    });
  } catch (error) {
    if (error.name === "CastError") {
      return res.status(400).json({
        message: "Invalid user ID"
      });
    }
    return res.status(500).json({
      message: "Failed to delete user"
    });
  }
};
