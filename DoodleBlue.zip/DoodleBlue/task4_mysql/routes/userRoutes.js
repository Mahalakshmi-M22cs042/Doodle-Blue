
const express = require("express");
const router = express.Router();
const userController = require("../controllers/userController");
const authMiddleware = require("../middleware/authMiddleware");
const userPermissionMiddleware = require("../middleware/userPermissionMiddleware");

// Public APIs
router.post("/signup", userController.signup);
router.post("/login", userController.login);

// Students and teachers
router.get(
    "/students",
    authMiddleware,
    userPermissionMiddleware("student", "teacher"),
    userController.getAllStudents
);

router.get(
    "/students/:id",
    authMiddleware,
    userPermissionMiddleware("student", "teacher"),
    userController.getStudentById
);

// Teachers only
router.get(
    "/teachers",
    authMiddleware,
    userPermissionMiddleware("teacher"),
    userController.getAllTeachers
);

router.get(
    "/teachers/:id",
    authMiddleware,
    userPermissionMiddleware("teacher"),
    userController.getTeacherById
);

// Update own profile
router.put(
    "/profile",
    authMiddleware,
    userPermissionMiddleware("student", "teacher"),
    userController.updateProfile
);

// Teacher updates a student
router.put(
    "/students/:id",
    authMiddleware,
    userPermissionMiddleware("teacher"),
    userController.updateStudent
);

module.exports = router;
