
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { UniqueConstraintError } = require("sequelize");
const User = require("../models/userModel");

function safeUser(user) {
    if (!user) return null;

    const data = user.toJSON();
    delete data.password;
    return data;
}

function validId(id) {
    return /^\d+$/.test(id) && Number(id) > 0;
}

function handleError(res, error, message) {
    console.error(error);

    if (error instanceof UniqueConstraintError) {
        return res.status(409).json({
            message: "Email already registered"
        });
    }

    if (error.name === "SequelizeValidationError") {
        return res.status(400).json({
            message: error.errors.map(e => e.message)
        });
    }

    return res.status(500).json({ message });
}

// PUBLIC: SIGNUP
exports.signup = async (req, res) => {
    try {
        const { name, email, password, role, department, phone } = req.body;

        if (
            typeof name !== "string" || !name.trim() ||
            typeof email !== "string" ||
            typeof password !== "string" ||
            !password ||
            !role
        ) {
            return res.status(400).json({
                message: "Name, email, password and role are required"
            });
        }

        if (!["student", "teacher"].includes(role)) {
            return res.status(400).json({
                message: "Role must be student or teacher"
            });
        }

        if (password.length < 8) {
            return res.status(400).json({
                message: "Password must contain at least 8 characters"
            });
        }

        const normalizedEmail = email.trim().toLowerCase();

        const existingUser = await User.findOne({
            where: { email: normalizedEmail }
        });

        if (existingUser) {
            return res.status(409).json({
                message: "Email already registered"
            });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const user = await User.create({
            name: name.trim(),
            email: normalizedEmail,
            password: hashedPassword,
            role,
            department,
            phone
        });

        return res.status(201).json({
            message: "Signup successful",
            user: safeUser(user)
        });
    } catch (error) {
        return handleError(res, error, "Signup failed");
    }
};

// PUBLIC: LOGIN
exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;

        if (
            typeof email !== "string" ||
            typeof password !== "string" ||
            !email || !password
        ) {
            return res.status(400).json({
                message: "Email and password are required"
            });
        }

        const user = await User.scope("withPassword").findOne({
            where: { email: email.trim().toLowerCase() }
        });

        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({
                message: "Invalid email or password"
            });
        }

        const token = jwt.sign(
            { id: user.id, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: process.env.JWT_EXPIRES_IN || "1h" }
        );

        return res.status(200).json({
            message: "Login successful",
            token,
            user: safeUser(user)
        });
    } catch (error) {
        return handleError(res, error, "Login failed");
    }
};

// GET ALL STUDENTS
exports.getAllStudents = async (req, res) => {
    try {
        const students = await User.findAll({
            where: { role: "student" },
            order: [["id", "ASC"]]
        });

        return res.status(200).json({
            count: students.length,
            students
        });
    } catch (error) {
        return handleError(res, error, "Failed to fetch students");
    }
};

// GET STUDENT BY ID
exports.getStudentById = async (req, res) => {
    try {
        if (!validId(req.params.id)) {
            return res.status(400).json({
                message: "Invalid student ID"
            });
        }

        const student = await User.findOne({
            where: {
                id: Number(req.params.id),
                role: "student"
            }
        });

        if (!student) {
            return res.status(404).json({
                message: "Student not found"
            });
        }

        return res.status(200).json({ student });
    } catch (error) {
        return handleError(res, error, "Failed to fetch student");
    }
};

// GET ALL TEACHERS
exports.getAllTeachers = async (req, res) => {
    try {
        const teachers = await User.findAll({
            where: { role: "teacher" },
            order: [["id", "ASC"]]
        });

        return res.status(200).json({
            count: teachers.length,
            teachers
        });
    } catch (error) {
        return handleError(res, error, "Failed to fetch teachers");
    }
};

// GET TEACHER BY ID
exports.getTeacherById = async (req, res) => {
    try {
        if (!validId(req.params.id)) {
            return res.status(400).json({
                message: "Invalid teacher ID"
            });
        }

        const teacher = await User.findOne({
            where: {
                id: Number(req.params.id),
                role: "teacher"
            }
        });

        if (!teacher) {
            return res.status(404).json({
                message: "Teacher not found"
            });
        }

        return res.status(200).json({ teacher });
    } catch (error) {
        return handleError(res, error, "Failed to fetch teacher");
    }
};

const allowedProfileFields = ["name", "email", "department", "phone"];

function getProfileUpdates(body) {
    const updates = {};

    for (const field of allowedProfileFields) {
        if (body[field] !== undefined) {
            updates[field] = body[field];
        }
    }

    if (updates.name !== undefined) {
        if (typeof updates.name !== "string" || !updates.name.trim()) {
            throw new Error("Name must not be empty");
        }

        updates.name = updates.name.trim();
    }

    if (updates.email !== undefined) {
        if (
            typeof updates.email !== "string" ||
            !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(updates.email)
        ) {
            throw new Error("Enter a valid email address");
        }

        updates.email = updates.email.trim().toLowerCase();
    }

    for (const field of ["department", "phone"]) {
        if (
            updates[field] !== undefined &&
            typeof updates[field] !== "string"
        ) {
            throw new Error(`${field} must be a string`);
        }
    }

    return updates;
}

// UPDATE OWN PROFILE: STUDENT OR TEACHER
exports.updateProfile = async (req, res) => {
    try {
        const updates = getProfileUpdates(req.body);

        const user = await User.findByPk(req.user.id);

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        await user.update(updates);

        return res.status(200).json({
            message: "Profile updated successfully",
            user: safeUser(user)
        });
    } catch (error) {
        if (error.message.startsWith("Name ") ||
            error.message.startsWith("Enter a valid") ||
            error.message.startsWith("department ") ||
            error.message.startsWith("phone ")) {
            return res.status(400).json({ message: error.message });
        }

        return handleError(res, error, "Failed to update profile");
    }
};

// TEACHER ONLY: UPDATE STUDENT
exports.updateStudent = async (req, res) => {
    try {
        if (!validId(req.params.id)) {
            return res.status(400).json({
                message: "Invalid student ID"
            });
        }

        const student = await User.findOne({
            where: {
                id: Number(req.params.id),
                role: "student"
            }
        });

        if (!student) {
            return res.status(404).json({
                message: "Student not found"
            });
        }

        const updates = getProfileUpdates(req.body);

        await student.update(updates);

        return res.status(200).json({
            message: "Student updated successfully",
            student: safeUser(student)
        });
    } catch (error) {
        if (error.message.startsWith("Name ") ||
            error.message.startsWith("Enter a valid") ||
            error.message.startsWith("department ") ||
            error.message.startsWith("phone ")) {
            return res.status(400).json({ message: error.message });
        }

        return handleError(res, error, "Failed to update student");
    }
};
