
// require("dotenv").config();
// const express = require("express");
// const sequelize = require("./config/db");
// const User = require("./models/userModel");
// const userRoutes = require("./routes/userRoutes");
// const app = express();
// const PORT = process.env.PORT || 5000;
// // Middleware
// app.use(express.json());
// // Home route
// app.get("/", (req, res) => {
//     res.status(200).json({
//         message: "College Portal API is running",
//         database: "MySQL",
//         ORM: "Sequelize"
//     });
// });
// // College portal APIs
// app.use("/api", userRoutes);
// // Start server
// async function startServer() {
//     try {
//         if (!process.env.JWT_SECRET) {
//             throw new Error("JWT_SECRET is missing in .env");
//         }
//         // Test MySQL connection
//         await sequelize.authenticate();
//         console.log("MySQL connected successfully");
//         // Create the users table if it does not exist
//         await sequelize.sync();
//         console.log("Users table is ready");
//         // Start Express server
//         app.listen(PORT, () => {
//             console.log(`Server running at http://localhost:${PORT}`);
//         });
//     } catch (error) {
//         console.error("Server startup failed:", error.message);
//         process.exit(1);
//     }
// }
// startServer();

require("dotenv").config();

const express = require("express");
const sequelize = require("./config/db");
const userRoutes = require("./routes/userRoutes");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());

app.get("/", (req, res) => {
    res.status(200).json({
        message: "College Portal API is running",
        database: "MySQL",
        ORM: "Sequelize"
    });
});
app.use("/api", userRoutes);

async function startServer() {
    try {
        if (!process.env.JWT_SECRET) {
            throw new Error("JWT_SECRET is missing in .env");
        }

        // Connect to MySQL without synchronizing tables
        await sequelize.authenticate();
        console.log("MySQL connected successfully");

        // Synchronization is disabled
        console.log("Sequelize synchronization is disabled");

        app.listen(PORT, () => {
            console.log(`Server running at http://localhost:${PORT}`);
        });
    } catch (error) {
        console.error("Server startup failed:", error.message);
        process.exit(1);
    }
}

startServer();
