const express = require('express');
require('dotenv').config();
const connectDB = require('./config/db');
const userRoutes =require("./routes/user.routes");
const app = express();
app.use(express.json());
app.use("/api/users",userRoutes);
connectDB().then(()=>{
    const port = process.env.PORT || 3000;
    app.listen(port,()=>{
        console.log(`Server is running on port ${port}`);
        console.log(`Server URL: http://localhost:${port}`);
    });
}).catch((err)=>{
    console.error("Failed to start server due to  MongoDB connecction error: ",err.message);
    process.exit(1);
});