const jwt = require("jsonwebtoken");

function authMiddleware(req, res, next) {
// Check whether the request object exists
if (!req || !req.headers) {
return res.status(400).json({
message: "Invalid request"
});
}

const authorization = req.headers.authorization;

console.log(authorization);

// Check whether the token is provided
if (!authorization || typeof authorization !== "string") {
    return res.status(401).json({
        message: "Unauthorized: Token is required"
    });
}

// Extract the Bearer token
const [scheme, token] = authorization.trim().split(/\s+/);

if (scheme !== "Bearer" || !token) {
    return res.status(401).json({
        message: "Invalid authorization format. Use Bearer <token>"
    });
}

// Check JWT secret
if (!process.env.JWT_SECRET) {
    return res.status(500).json({
        message: "JWT_SECRET is missing from environment variables"
    });
}

try {
    // Verify the JWT token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Attach decoded token data to the request
    req.user = decoded;

    // Continue to the next middleware/controller
    return next();
} catch (error) {
    return res.status(401).json({
        message: "Invalid or expired token"
    });
}

}

module.exports = authMiddleware;