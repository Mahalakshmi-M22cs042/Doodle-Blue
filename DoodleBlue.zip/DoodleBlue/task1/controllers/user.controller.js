const UserService = require("../services/user.service");
const userService = new UserService();
class UserController {
    //for Sginup
    async userSignup(req, res) {
        try{
            const { name, email, password } = req.body;
            if (!name || !email || !password) {
                return res.status(400).json({
                    message: "Name, email, and password are required"
                });
            }
            const savedUser = await userService.userSignup({ name, email, password });
            return res.status(201).json({
                message: "User signed up successfully",
                data: savedUser
            });
        } catch (err) {
            return res.status(500).json({
                error: err.message
            });
        }
    }
    // GET - Get all users
    async getAllUsers(req, res) {
        try {
            const users = await userService.getAllUsers();
            return res.status(200).json({
                message: "Users retrieved successfully",
                data: users
            });
        } catch (err) {
            return res.status(500).json({
                error: err.message
            });
        }
    }
    // GET - Get user by ID
    async getUserById(req, res) {
        try {
            const user = await userService.getUserById(req.params.id);
            if (!user) {
                return res.status(404).json({
                    message: "User not found"
                });
            }
            return res.status(200).json({
                message: "User retrieved successfully",
                data: user
            });
        } catch (err) {
            return res.status(500).json({
                error: err.message
            });
        }
    }
    // POST - Create a new user
    async createUser(req, res) {
        try {
            const { name, email } = req.body;
            if (!name || !email) {
                return res.status(400).json({
                    message: 'Both "name" and "email" are required'
                });
            }
            const newUser = await userService.createUser({
                name,
                email
            });
            return res.status(201).json({
                message: "User created successfully",
                data: newUser
            });
        } catch (err) {
            if (err.code === 11000) {
                return res.status(409).json({
                    message: "A user with this email already exists"
                });
            }
            return res.status(500).json({
                error: err.message
            });
        }
    }
    // PUT - Update all editable user fields
    async updateUser(req, res) {
    try {
        const { name, email } = req.body;
        if (name === undefined && email === undefined) {
            return res.status(400).json({
                message: "Provide at least one field: name or email"
            });
        }
        const updates = {};
        if (name !== undefined) updates.name = name;
        if (email !== undefined) updates.email = email;

        const user = await userService.patchUser(
            req.params.id,
            updates
        );
        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }
        return res.status(200).json({
            message: "User updated successfully",
            data: user
        });
    } catch (err) {
        if (err.code === 11000) {
            return res.status(409).json({
                message: "A user with this email already exists"
            });
        }
        if (err.name === "ValidationError") {
            return res.status(400).json({
                message: err.message
            });
        }
        return res.status(500).json({
            error: err.message
        });
    }
}
    // PATCH - Update selected user fields
    async patchUser(req, res) {
        try {
            const updates = {};
            const { name, email } = req.body;
            if (name !== undefined) updates.name = name;
            if (email !== undefined) updates.email = email;
            if (Object.keys(updates).length === 0) {
                return res.status(400).json({
                    message: "Provide name or email to update"
                });
            }
            const updatedUser = await userService.patchUser(
                req.params.id,
                updates
            );
            if (!updatedUser) {
                return res.status(404).json({
                    message: "User not found or invalid ID"
                });
            }
            return res.status(200).json({
                message: "User partially updated successfully",
                data: updatedUser
            });
        } catch (err) {
            if (err.code === 11000) {
                return res.status(409).json({
                    message: "A user with this email already exists"
                });
            }
            return res.status(500).json({
                error: err.message
            });
        }
    }
    // DELETE - Delete user by ID
    // Normal delete
    async deleteUser(req, res) {
        try {
            const user = await userService.deleteUser(req.params.id);
            if (!user) {
                return res.status(404).json({
                    message: "User not found"
                });
            }
            return res.status(200).json({
                message: "User deleted successfully",
                data: user
            });
        } catch (err) {
            return res.status(500).json({
                error: err.message
            });
        }
    }
    // Hard delete
    async hardDeleteUser(req, res) {
        try {
            const user = await userService.hardDeleteUser(req.params.id);
            if (!user) {
                return res.status(404).json({
                    message: "User not found"
                });
            }
            return res.status(200).json({
                message: "User permanently deleted",
                data: user
            });
        } catch (err) {
            return res.status(500).json({
                error: err.message
            });
        }
    }
    //getUSerPRofile
async getUserProfile(req, res) {
    try {
        const userId = req.user.id; // Assuming the user ID is stored in req.user by the auth middleware
        const user = await userService.getUserById(userId);
        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }
        return res.status(200).json({
            message: "User profile retrieved successfully",
            data: user
        });
    } catch (err) {
        return res.status(500).json({
            error: err.message
        });
    }
}
    // Soft delete
    async softDeleteUser(req, res) {
        try {
            const user = await userService.softDeleteUser(req.params.id);
            if (!user) {
                return res.status(404).json({
                    message: "User not found or already deleted"
                });
            }
            return res.status(200).json({
                message: "User soft-deleted successfully",
                data: user
            });
        } catch (err) {
            return res.status(500).json({
                error: err.message
            });
        }
    }

    async loginUser(req, res) {
        try {
            const { email, password } = req.body;
            if (!email || !password) {
                return res.status(400).json({
                    message: "Email and password are required"
                });
            }

            const result = await userService.loginUser({ email, password });
            return res.status(200).json({
                message: "Login successful",
                ...result
            });
        } catch (err) {
            return res.status(401).json({
                error: err.message
            });
        }
    }
}
module.exports = new UserController();
