const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');
const authMiddleware = require('../middleware/auth.middleware');

router.post('/signup', (req, res) => userController.userSignup(req, res));
router.post('/login', (req, res) => userController.loginUser(req, res));
router.get('/profile', authMiddleware, (req, res) => userController.getUserProfile(req, res));
router.get('/', authMiddleware, (req, res) => userController.getAllUsers(req, res));
router.post('/', authMiddleware, (req, res) => userController.createUser(req, res));
router.get('/:id', authMiddleware, (req, res) => userController.getUserById(req, res));
router.put('/:id', authMiddleware, (req, res) => userController.updateUser(req, res));
router.patch('/:id', authMiddleware, (req, res) => userController.patchUser(req, res));
router.patch('/:id/soft-delete', authMiddleware, (req, res) => userController.softDeleteUser(req, res));
router.delete('/:id/hard-delete', authMiddleware, (req, res) => userController.hardDeleteUser(req, res));
router.delete('/:id', authMiddleware, (req, res) => userController.deleteUser(req, res));

module.exports = router;