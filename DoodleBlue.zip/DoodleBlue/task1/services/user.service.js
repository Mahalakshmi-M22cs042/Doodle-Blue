
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/user.model");

class UserService {
    async userSignup({ name, email, password }) {
        const salt = 10;
        const hashedPassword = await bcrypt.hash(password, salt);
        const savedUser = await User.create({ name, email, password: hashedPassword });
        return savedUser;
    }

    async getAllUsers() {
        return await User.find({ isActive: true });
    }

    async getUserById(id) {
        if (!mongoose.isValidObjectId(id)) {
            return null;
        }

        return await User.findById(id);
    }

    async createUser({ name, email, password }) {
        const userData = { name, email };

        if (password) {
            userData.password = password;
        }

        return await User.create(userData);
    }

    async updateUser(id, { name, email }) {
        if (!mongoose.isValidObjectId(id)) {
            return null;
        }

        return await User.findByIdAndUpdate(
            id,
            { name, email },
            {
                new: true,
                runValidators: true
            }
        );
    }

    async patchUser(id, updates) {
        if (!mongoose.isValidObjectId(id)) {
            return null;
        }

        const allowedFields = ["name", "email"];
        const filteredUpdates = {};

        for (const field of allowedFields) {
            if (updates[field] !== undefined) {
                filteredUpdates[field] = updates[field];
            }
        }

        if (Object.keys(filteredUpdates).length === 0) {
            throw new Error("Provide name or email to update");
        }

        return await User.findByIdAndUpdate(
            id,
            { $set: filteredUpdates },
            {
                new: true,
                runValidators: true
            }
        );
    }

    async deleteUser(id) {
        if (!mongoose.isValidObjectId(id)) {
            return null;
        }

        return await User.findByIdAndDelete(id);
    }

    async hardDeleteUser(id) {
        if (!mongoose.isValidObjectId(id)) {
            return null;
        }
        return await User.findByIdAndDelete(id);
    }

    async softDeleteUser(id) {
        if (!mongoose.isValidObjectId(id)) {
            return null;
        }

        return await User.findOneAndUpdate(
            {
                _id: id,
                isActive: true
            },
            {
                $set: { isActive: false }
            },
            {
                new: true,
                runValidators: true
            }
        );
    }

    async loginUser({ email, password }) {
        const user = await User.findOne({ email }).select("+password");
        if (!user) {
            throw new Error("Invalid email or password");
        }

        if (!user.isActive) {
            throw new Error("This account has been deactivated");
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            throw new Error("Invalid email or password");
        }

        const jwtSecret = process.env.JWT_SECRET;
        if (!jwtSecret) {
            throw new Error("JWT_SECRET is missing from environment variables");
        }

        const payload = {
            id: user._id,
            name: user.name,
            email: user.email,
            isActive: user.isActive
        };

        const token = jwt.sign(payload, jwtSecret, { expiresIn: "1d" });
        const userWithoutPassword = user.toObject();
        delete userWithoutPassword.password;

        return {
            token,
            user: userWithoutPassword
        };
    }
}

module.exports = UserService;