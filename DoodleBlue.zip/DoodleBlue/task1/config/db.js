const mongoose = require('mongoose');
const dns = require('node:dns');
const connectDB = async () => {
    const uri = process.env.MONGO_URL||process.env.MONGO_URI;
    if (!uri) {
        console.error("Error: Neither MONGO_URL nor MONGO_URI is defined in your environment file(.env)");
        process.exit(1);
    }
    try {
        try {
            await mongoose.connect(uri);
        } catch (err) {
            if (err.code !== 'EBADRESP') {
                throw err;
            }
            dns.setServers(['1.1.1.1', '8.8.8.8']);
            console.warn('System DNS returned an invalid SRV response; retrying with alternate DNS resolvers.');
            await mongoose.connect(uri);
        }
        console.log('Connected to MongoDB successfully');
    } catch (err) {
        console.error('Failed to connect to MongoDB:', err.message);
        process.exit(1);
    }
};
module.exports = connectDB;